import React, { useReducer, createContext, useEffect } from 'react';
import { products } from '../common/actions/data';
// import {AppContext} from './appContext';
import productReducer from '../reducers/productReducer/productReducer';
import addressReducer from '../reducers/addressReducer/addressrReducer';
import cartReducer from '../reducers/cartReducer/cartReducer';
export const Context = createContext({});
const state = {
  address: [],
  product:[],
  cart: []
}
export default function AppStateProvider({ children }) {
  // console.log(initialCartState)
  const [product, dispatchProduct] = useReducer(productReducer, state)
  const [address, dispatchAddress] = useReducer(addressReducer, state);
  const [cart, dispatchCart] = useReducer(cartReducer, state);

  console.log(cart.cart)
  //Get all product and set in local state variable
  useEffect(() => {
    dispatchProduct({type:"GET_ALL_PRODUCTS", payload:products})
  },[products])
  return (
    <Context.Provider
      value={{
        addressState: address.address,
        dispatchCart,
        cartState: cart.cart,
        dispatchAddress,
        prodState: product.product,
        dispatchProduct
      }}
    >
      {children}
    </Context.Provider>
  )
}
