import React, { useContext } from 'react';
import './Home.css';
import MostPropularProducts from '../../components/product/MostPropularProducts';
import OfferOfTheDayProducts from '../../components/product/OfferOfTheDayProducts';
import SuggestedProducts from '../../components/product/SuggestedProducts';
import TopSelectionProducts from '../../components/product/TopSelectionProducts';
import Auth from '../../components/authentication/Auth';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Context } from '../../context/AppState';

import Sliders from '../../components/sliders/Sliders';
export default function Home() {
    // console.log(useContext(Context))
    return (
        <div className="homeContainer">
            <div className="homeSliderContainer">
                <Sliders/>
            </div>
            <MostPropularProducts/>
            {/* <OfferOfTheDayProducts />
            <SuggestedProducts/>
            <TopSelectionProducts /> */}
            {/* <Auth/> */}
            <FontAwesomeIcon icon="fa-solid fa-angle-right" style={{color: "red", zIndex:10}} />
        </div>
    );
}
