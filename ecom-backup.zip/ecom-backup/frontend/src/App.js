import './App.css';
import About from './components/about/About';
import Contact from './components/contact/Contact';
import Home from './pages/home/Home';
import Auth from './components/authentication/Auth';
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  Outlet,
  history
} from "react-router-dom";
import Navbar from './components/navbar/Navbar';
import Products from './components/product/Products';
import ProductDetails from './components/product/productdetails/ProductDetails';
import Cart from './components/cart/Cart';
import AddAddress from './components/address/AddAddress';
import AppStateProvider from './context/AppState';

function App() {
  return (
    <AppStateProvider>
    <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/about" element={<About />}/>
        <Route path="/contact" element={<Contact />} />
        <Route path="/register" element={<Auth />} />
        <Route path="/products" element={<Products />} />
        <Route path="/details/:id" element={<ProductDetails />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/address" element={<AddAddress/>}/>
      </Routes>
      </BrowserRouter>
    </AppStateProvider>
  );
}

export default App;

