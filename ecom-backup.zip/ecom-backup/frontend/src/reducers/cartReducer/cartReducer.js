
import { ADD_TO_CART, DELETE_FROM_CART, UPDATE_CART, DELETE_QUANTITY, ADD_QUANTITY } from "../../actions/action";
export const initialCartState = [
    {
        recipient_name: "",
        recipient_mobile: "",
        address_one: "",
        address_two: "",
        city: "",
        state: "",
        zip: "",
        isComplete: false,
        isAddToCart:false
    }
];
const cartReducer = (state, action) => {
    switch (action.type)
    {
        case ADD_TO_CART:
            return {
                ...state.cart,
                cart:[...state.cart,action.payload]
            };
        case DELETE_FROM_CART:
            return {};
        case UPDATE_CART:
            return {
                ...state.cart,
               cart: state.cart.map((eachCart) => {
                   return eachCart.id!=action.payload.id? action.payload :{...eachCart}
                })
            };
        case DELETE_QUANTITY:
            return {    
                ...state.cart,
                cart: state.cart.map((eachCart) => {
                        if(eachCart.product.id===action.payload && eachCart.prodQuantity===1) {
                            return{...eachCart, prodQuantity: 1}
                        }
                        else if(eachCart.product.id === action.payload)
                            return { ...eachCart, prodQuantity: eachCart.prodQuantity - 1 }

                        else
                            return { ...eachCart }
                })
            };
        case ADD_QUANTITY:
            return {
                ...state.cart,
                cart: state.cart.map((eachCart) => {
                  return eachCart.product.id === action.payload
                        ?
                        { ...eachCart, prodQuantity: eachCart.prodQuantity+1 }
                        :
                        { ...eachCart }
                })
            }
        default:
            return state;
    }
}
export default cartReducer;