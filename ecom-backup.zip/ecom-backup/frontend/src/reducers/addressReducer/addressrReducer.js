
import { ADD_ADDRESS, UPDATE_ADDRESS, DELETE_ADDRESS, SET_ADDRESS } from "../../actions/action";
const addressReducer = (state, action) => {
    // console.log(state.address)
    switch (action.type)
    {
        case ADD_ADDRESS:
            return {
                ...state.address,
                address: [...state.address, action.payload]
            }
        case UPDATE_ADDRESS:
            return {
                 ...state.address,
                 address: state.address.map((eachAddress) => {
                   return eachAddress.address_id===action.payload.address_id? action.payload :{...eachAddress}
                })
            };
        case DELETE_ADDRESS:
            return {};
        case SET_ADDRESS:
            return {
                ...state.address,
                address: state.address.map((eachAddress) => {
                   return eachAddress.address_id===action.payload?{...eachAddress, select_address:true}:{...eachAddress, select_address:false}
                })
            }
        default:
            return state;
    }
}
export default addressReducer;