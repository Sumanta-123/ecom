import React from 'react'
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import './slider.css';
// import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used


export default function Sliders() {
  return (
    <div className="sliderMask">
          {/* <h1>Slider heading</h1> */}
          {/* <div className="slides">{ }</div> */}
          <Link to="/" className="slides">
                <div className="slideImgContainer" style={{  height: "600px", overflow:"hidden",
    position: "relative",
    width: "100%"}}>
                  <img src="https://m.media-amazon.com/images/I/61N83xtyr6L._SX3000_.jpg" alt="alt" style={{objectFit:"cover", height:"100%", maxWidth:"100%", maxHeight:"100%", zIndex:1}}/>
                </div>
          </Link>
          {/* <FontAwesomeIcon icon="fa-regular fa-angle-left" /> */}
          <FontAwesomeIcon icon="fa-solid fa-angle-right" style={{ color: "red", zIndex: 10, }} />
    </div>
  )
}
