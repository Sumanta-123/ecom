import React, { useContext, useState } from 'react';
import { ADD_QUANTITY, DELETE_QUANTITY } from '../../actions/action';
import './cart.css';
import { Link } from "react-router-dom";
import { Context } from '../../context/AppState';
import { products } from '../../common/actions/data';
export default function Cart() {
    const {cartState,  addressState, dispatchCart } = useContext(Context);
    // const [dispatchAddress, setDispatchAddress] = useState();
    console.log(cartState)
    const handleQuantity = (acc, id) => {
        if (acc === ADD_QUANTITY)
        {
            // console.log(id)
            dispatchCart({type: ADD_QUANTITY, payload:id})
        } else if (acc === DELETE_QUANTITY)
        {
            // console.log(id)
            dispatchCart({type: DELETE_QUANTITY, payload:id})
        }
    }
    const cartItem = cartState.length ===0 ? <div className="cartItem"><h3>No items added to your cart</h3></div>: cartState.map((eachCart, _index) => {
        return(
            <div key={_index} className="cartItemList">
                <div>
                <img src={eachCart.product.images[0]} width="50" height="50"/>
                </div>
                <div className="cartProductName">
                    <h5>{eachCart.product.title}</h5>
                </div>
                <div className="cartQty">
                    <button
                        onClick={
                            () => handleQuantity(
                                DELETE_QUANTITY,
                                eachCart.product.id
                            )}
                    >-</button>
                    
                <span>{eachCart.prodQuantity}</span>
                    <button
                        onClick={
                            () => handleQuantity(
                                ADD_QUANTITY,
                                eachCart.product.id)}
                    >+</button>
                </div>
                <div className="cartItemQty">
                    <span>{eachCart.prodQuantity}</span>
                    <span> * </span>
                    <span>{eachCart.product.price}</span>
                    <span> = </span>
                    <strong>{(eachCart.prodQuantity)*(eachCart.product.price)}</strong>
                </div>
                <div className="cartRemoveItem"><span>X</span></div>
            </div>
        )})
  return (
      <div className="cartContainer">
            <div className="cartItem">
                {cartItem}
            </div>
        <div className="cartBuyNow">
            <div className="cartBuyHeader">
                <span>Hi, Sumanta kumar.</span>
                <span>Here is your order details</span>
            </div>
            <table className="cartBuyTable">
                <tbody>
                    <tr>
                        <td>Total Amount:</td>
                        <td><span>Rs:</span> <strong>200.00</strong></td>
                    </tr>
                    <tr>
                        <td>Total Items:</td>
                        <td>4</td>
                    </tr>
                    <tr>
                        <td>Taxes added:</td>
                        <td>2%</td>
                    </tr>
                    <tr>
                        <td>Amount after taxes:</td>
                        <td><span>Rs:</span> <span>204.00</span></td>
                    </tr>
                                        
                    <tr>
                        <td>Delivered charge:</td>
                        <td><span>Rs:</span> <span>40.00</span></td>
                    </tr>
                    <tr>
                        <td>You saved:</td>
                        <td><span>Rs:</span> <span>30.00</span></td>
                    </tr>
                    <tr className="cartTotalPayableAmount">
                        <td><strong>Total payable amount:</strong></td>
                        <td><strong>Rs:</strong> <strong>114.00</strong></td>
                    </tr>
                </tbody>
            </table>
              <Link to="/place-order" className="cartPlaceYourBtn">Place your oders</Link>
            <div className="cartDispatchAddress">
                  <h4>Your delivery address: </h4>
                  <div className="cartDispContainer">
                    {
                      addressState.map(dispAdrs => {
                      if (dispAdrs.select_address)
                      {
                        return (
                            <div className="dispatchAddress" key={dispAdrs.address_id}>
                                <h5>{dispAdrs.recipient_name}</h5>
                                <h5>{dispAdrs.recipient_mobile}</h5>
                                <div>{`${dispAdrs.address_one}, ${dispAdrs.address_two}, ${dispAdrs.city}, ${dispAdrs.state} ${dispAdrs.zip}`}</div>
                            </div>
                        )}
                      })
                    }
                    <Link to="/address">Change adderess <span>&#9998;</span></Link>
                </div>
            </div>
        </div>
    </div>
  )
}
