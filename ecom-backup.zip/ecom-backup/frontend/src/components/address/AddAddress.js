import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router';
import  {Context}  from '../../context/AppState';
import AddressList from './AddressList';
import "./addaddress.css"
export default function AddAddress() {
  const naviGate = useNavigate();
  const { addressState, dispatchAddress } = useContext(Context);
  const [update, setUpdate] = useState(false)
  console.log(addressState)
  const [inputValue, setInputValues] = useState({
    address_one: "",
    address_two: "",
    city: "",
    recipient_mobile: "",
    recipient_name: "",
    state: "",
    zip: "",
    address_id: Date.now(),
    select_address: false
  });
  // console.log(addressState)
  const handleChange = (event) => {
    const { name, value } = event.target;
    setInputValues({ ...inputValue, [name]: value });
  }
  //Update address
  const handleUpdateAddress = (e,id) => {
    e.preventDefault()
    const [formData] = addressState.filter(addrs => { return addrs.address_id === id ? addrs : null });
    setInputValues(formData)
    setUpdate(true)
  }
  //Submit address
  const handleSubmit = (e) => {
    e.preventDefault()
    if (!update)
    {
      dispatchAddress({
        type: "ADD_ADDRESS",
        payload: inputValue
      })
    } else
    {
      dispatchAddress({
        type: "UPDATE_ADDRESS",
        payload: inputValue
      })
      setUpdate(false)
    }
    setInputValues({
      address_one: "",
      address_two: "",
      city: "",
      recipient_mobile: "",
      recipient_name: "",
      state: "",
      zip: "",
      address_id: Date.now(),
      select_address: false
    })
  }
  //Show delivered address
  const handleSetDeliveryAddress = (e,id) => {
    e.preventDefault()
    dispatchAddress({
      type: "SET_ADDRESS",
      payload: id
    })
    naviGate("/cart", { replace: false });
  }
  return (
    <div className="addAddressContainer">
      <div className="addAddress">
        <h2>Add new address</h2>
        <form className="addAddressForm" onSubmit={handleSubmit}>
          <fieldset className="addAddressBox">
            <legend>Add recipient</legend>
            <div>
              <label>Recipient name:</label>
              <input
                type="text"
                value={inputValue.recipient_name}
                onChange={handleChange}
                name="recipient_name"
              />
            </div>
            <div>
              <label>Recipient mobile:</label>
              <input
                type="text"
                value={inputValue.recipient_mobile}
                onChange={handleChange}
                name="recipient_mobile"
              />
            </div>
          </fieldset>
          <fieldset className="addAddressBox">
            <legend>Add address</legend>
            <div>
              <label>Address line 1:</label>
              <input
                type="text"
                value={inputValue.address_one}
                onChange={handleChange}
                name="address_one"
              />
            </div>
            <div>
              <label>Address line 2:</label>
              <input
                type="text"
                value={inputValue.address_two}
                onChange={handleChange}
                name="address_two"
              />
            </div>
            <div>
              <label>City:</label>
              <input
                type="text"
                value={inputValue.city}
                onChange={handleChange}
                name="city"
              />
            </div>
            <div>
              <label>State:</label>
              <input
                type="text"
                value={inputValue.state}
                onChange={handleChange}
                name="state"
              />
            </div>
            <div>
              <label>Zip code:</label>
              <input
                type="text"
                value={inputValue.zip}
                onChange={handleChange}
                name="zip"
              />
            </div>
          </fieldset>
          <input 
              type="submit"
              className="addAddressBtn"
            value="Add address"
            disabled={!update?false:true}
            />
          <input
            type="submit"
            className="addAddressBtn updateBtn"
            disabled={!update ? true : false}
            value="Update"
            />
        </form>
      </div>
      <AddressList
        updateAddress={(e, id) => handleUpdateAddress(e, id)}
        setDeliveryAddress={(e,id) => handleSetDeliveryAddress(e,id)}
      />
    </div>
  )
}
