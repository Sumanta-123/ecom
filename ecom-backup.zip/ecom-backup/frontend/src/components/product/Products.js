import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { products } from '../../common/actions/data'
import ProdCardView from './productview/ProdCardView'
import ProdListView from './productview/ProdListView'

export default function Products() {
  const [prodView, setProdView] = useState("card")
  return (
    <div className="product">
      <div className="prodContainer">
        <div className="prodFilterPanel">
          <ul>
            <li>
              <div className="filterItem">
                <span>Department</span>
                <ul className="filterList">
                  <li>Craft Materials</li>
                  <li>Furniture</li>
                  <li>Heating, Cooling & Air</li>
                </ul>
              </div>
            </li>
            <li>
              <div className="filterItem">
                <span>Department</span>
                <ul className="filterList">
                  <li>Home Improvement</li>
                  <li>Home Storage & Organization</li>
                  <li>One</li>
                </ul>
              </div>
            </li>
            <li>
              <div className="filterItem">
                <span>Department</span>
                <ul className="filterList">
                  <li>One</li>
                  <li>One</li>
                  <li>One</li>
                </ul>
              </div>
            </li>
            <li>
              <div className="filterItem">
                <span>Made for Amazone brands</span>
                <ul className="filterList">
                  <li>
                    <input type="checkbox" value={"Color"} /> <span>Made for Amazone</span>
                  </li>
                  <li>
                    <input type="checkbox" value={"Prime"} /> <span>Prime</span>
                  </li>
                  <li>One</li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        <div className="prodViewPanel">
          {
            products.map((prod, _index) => {
              return (
                prodView == "card" ? <ProdCardView product={prod} key={_index}/> : <ProdListView />
              )
            })
          }
        </div>
      </div>
    </div>
  )
}
