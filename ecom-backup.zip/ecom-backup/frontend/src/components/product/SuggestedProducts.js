import React from 'react';

function SuggestedProducts() {
    return (
        <div className="productContainer bgWhite">
            <h3>Suggested product for you</h3>
            <h3>Suggested product for you</h3>
            <h3>Suggested product for you</h3>
        </div>
    );
}

export default SuggestedProducts;
