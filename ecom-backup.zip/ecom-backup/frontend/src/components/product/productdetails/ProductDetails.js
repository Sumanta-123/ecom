import React, { useContext, useEffect, useState } from 'react';
import { Link , useNavigate} from 'react-router-dom';
import { Context } from '../../../context/AppState';
import "./productdetails.css";

export default function ProductDetails() {
    
    const { prodState, cartState, dispatchCart } = useContext(Context)
    // console.log(prodState.id)
    console.log(cartState)
    const naviGate =  useNavigate()
    // const [totalPrice, setTotalPrice] = useState(prodState.price);
    const [image, setImage] = useState(prodState.images[0]);
    // const [quantiy, setQuantiy] = useState(1);
    // const totalPrice = itemPrice.quantiy;
    // function updatePrice(qty, price) {
    //     let totalPrice = (qty * price).toString();
    //     // totalPrice.toString();
    //     // console.log(typeof (totalPrice));
    //     // parseFloat(totalPrice.toFixed(2))
    //    let x =  Math.round((totalPrice + Number.EPSILON) * 100) / 100
    //     setTotalPrice(totalPrice,x)
    // }

    //Thumbnail image changes
    const handleChangeImage = (img) => {
        setImage(img)
    }
    //Quantity udpation handler
    // const handleQuantityChange = (qty) => {
    //     if (qty === "add")
    //     {
    //         setQuantiy(quantiy + 1)
    //     } else
    //     {
    //         if (quantiy <= 1)
    //         {
    //             setQuantiy(1)
    //         } else
    //         {
    //             setQuantiy(quantiy-1)
    //         }
    //     }
    //  updatePrice(quantiy, prodState.price)
    // }
    // useEffect(() => {
    //     setImage( image, prodState.images[0] )
    // }, [])

    const imgIcons = prodState.images.map((img, key) => (<img key={key} src={img} width="40" height="40" onClick={()=>handleChangeImage(img)} />))
    
    //add to cart
    const handleAddToCart = (e) => {
        // console.log(id)
        // console.log(prodState)
        e.preventDefault()
        const cartObjet = {
            product: prodState,
            isAddToCart: true,
            isComplete: false,
            prodQuantity: 1
        }
        dispatchCart({ type: "ADD_TO_CART", payload: cartObjet })
        // naviGate(`/cart`, {replace:true})
    }
    const goToCart = () => {
        naviGate(`/cart`, {replace:false})
    }
  return (
    <div className="pDetailContainer">
          <div className="pDetailImgPanel">
              <div className="pDetailIconImg">
                {imgIcons}
              </div>
              <div className="pDetailLargeImg">
                  <img src={image} width="600" height="600"/>
              </div>
          </div>
          <div className="pDetailPanel">
              <div className="pDetailDesp">
                  <h3>
                      {prodState.description}
                  </h3>
              </div>
              <div className="pPriceBox">
                  <table className="pMrpTable">
                      <tbody>
                          <tr>
                              <td>⭐⭐⭐⭐⭐</td>
                              <td><span>9</span> ratings</td>
                          </tr>
                          <tr>
                              <td>M.R.P.:</td>
                              <td><span>₹:</span>200.00</td>
                          </tr>
                            <tr>
                              <td>Discount:</td>
                              <td><span>₹:</span>200.00</td>
                          </tr>
                          <tr>
                              <td></td>
                              <td>Offer ends <span>1</span> day</td>
                          </tr>
                            <tr>
                              <td></td>
                              <td><span>Includes all taxes</span></td>
                          </tr>
                      </tbody>
                    </table>
                  <div className="pPricePerItem">
                        <div>
                            <div className="pTotalPrice">
                              <span>Total</span> <span>₹:</span> <strong>{prodState.price}</strong>
                            </div>
                            {/* <div className="pQuantity">
                              <button className="removeQty" onClick={()=>handleQuantityChange("remove")}>-</button>
                              <span>{ quantiy }</span>
                              <button className="addQty" onClick={()=>handleQuantityChange("add")} >+</button>
                            </div> */}
                        </div>
                        <div>
                          <div>
                              <span>Free Delivery:</span> <strong>Thursday, May 19</strong>
                          </div>
                          <div>
                              {
                                cartState.isAddToCart || cartState.length === 0 ?
                                    <button
                                        className="addToCartBtn"
                                        onClick={(e) => handleAddToCart(e)} >
                                        Add to cart
                                    </button>
                                  : <button
                                        className="addToCartBtn"
                                        onClick={goToCart} >
                                        Go to cart
                                    </button>
                                }
                              <button to="/">Buy now</button>
                          </div>
                        </div>
                  </div>
              </div>
              <div className="pFeatureDetails">
                  <ul>
                      <li>Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                  </ul>
              </div>
          </div>
    </div>
  )
}
