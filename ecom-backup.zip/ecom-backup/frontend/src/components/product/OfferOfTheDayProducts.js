import React from 'react';

const OfferOfTheDayProducts =()=> {
    return (
        <div className="productContainer bgSecondary">
            <h3>Offer of the day Products</h3>
            <h3>Offer of the day Products</h3>
            <h3>Offer of the day Products</h3>
            <h3>Offer of the day Products</h3>
        </div>
    );
}

export default OfferOfTheDayProducts;
