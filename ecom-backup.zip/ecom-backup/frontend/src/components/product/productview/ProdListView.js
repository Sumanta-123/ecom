import React from 'react'

export default function prodListView() {
  return (
    <div>prodListView</div>
  )
}
