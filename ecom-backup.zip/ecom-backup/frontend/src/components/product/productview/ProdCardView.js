import React, { useContext, useState } from 'react';
import "./prodview.css";
import { Link, useNavigate } from 'react-router-dom';
import { products } from '../../../common/actions/data';
import { Context } from '../../../context/AppState';
export default function ProdCardView(props) {
  const [add, setAddToCart] = useState(false);
  const naviGate = useNavigate();
  const { prodState, dispatchCart, dispatchProduct } = useContext(Context);
  // console.log(prodState)

  //Filter single product by the id
  const handleProductDetails = (e, id) => {
    e.preventDefault()
    dispatchProduct({ type: "PRODUCT_DETAILS", payload: id })
    naviGate(`/details/${id}`, {replace:true})
  }

  //Add to cart 
  const handleAddToCart = (e,id) => {
    e.preventDefault()
    e.stopPropagation();
    setAddToCart(true)
    const [sigleProduct] = products.filter((eachProd) => {
      if (eachProd.id === id) return eachProd
    })
    const cartObjet = {product:sigleProduct, isAddToCart:true, isComplete:false, prodQuantity:1}
    dispatchCart({ type: "ADD_TO_CART", payload: cartObjet })
  }

  return (
    <div onClick={(e)=>handleProductDetails(e, props.product.id)} className="pCardContainer">
          <div className="pCards">
            <div className="pCardHeader">
              <div className="pCardImgBox">
                <img className="cardImg" src={props.product.images[0]}/>
              </div>
            </div>
            <div className="pCardBody">
              <h5>
                {props.product.description}
              </h5>
            </div>
            <div className="pCardFooter">
              <div><span>⭐⭐⭐⭐⭐</span><span>200</span></div>
              <div><span>Rs:</span><span>{props.product.price}</span><span>{ props.product.price}</span><span>({props.product.offer.discount}% off)</span></div>
              <div><span>Get it</span> <strong>On Date</strong></div>
              <div>Delivery charge is {props.product.shiping_criteria.shiping_charge}</div>
              <button disabled={add ? true : false} onClick={(e) => handleAddToCart(e,props.product.id)}>Add to cart</button>
            </div>
          </div>
    </div>
  )
}
