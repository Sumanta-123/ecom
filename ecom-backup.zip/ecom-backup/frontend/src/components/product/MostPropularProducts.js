import React from 'react';
import './Product.css';
import ProductGruops from './ProductGruops';
import {products} from "../../common/actions/data"
import { Link } from 'react-router-dom';
const MostPropularProducts =()=> {
    return (
        <div className="productContainer bgWhite" style={{position:"relative",overflow:"hidden"}}>
            <div className="prodSignInBand">
                <span>
                    You are on labla store.com. You can also shop on Labla India for millions of products with fast local delivery.
                    <Link to="/"> click here go to Sign in</Link>
                </span>
            </div>
            <div className="productGroup">
                <ProductGruops data={products} />
            </div>
        </div>
    );
}

export default MostPropularProducts;
    