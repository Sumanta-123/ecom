export const ADD_ADDRESS = "ADD_ADDRESS";
export const UPDATE_ADDRESS = "UPDATE_ADDRESS";
export const DELETE_ADDRESS = "DELETE_ADDRESS";
export const SET_ADDRESS = "SET_ADDRESS";
//cart action
export const ADD_TO_CART = "ADD_TO_CART";
export const DELETE_FROM_CART = "DELETE_FROM_CART";
export const UPDATE_CART = "UPDATE_CART";
export const DELETE_QUANTITY = "DELETE_QUANTITY";
export const ADD_QUANTITY = "ADD_QUANTITY";

//product action
export const PRODUCT_DETAILS = "PRODUCT_DETAILS";
export const GET_ALL_PRODUCTS = "GET_ALL_PRODUCTS";