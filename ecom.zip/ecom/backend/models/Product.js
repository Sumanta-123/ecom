const {Schema, model} = require('mongoose');

const productSchema = new Schema({
    product_id: {
        type: String,
        unique: true,
        trim: true,
        required: true
    },
    title: {
        type: String,
        trim: true,
        required: true
    },
    price: {
        type: Number,
        required: true
    },      
    description: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    checked: {
        type: Boolean,
        default: false
    },
    sold: {
        type: Boolean,
        default: false
    },
    quantity: {
        type: Number,
        // required: true
    },
    item_details: {
        type: Object
    },
    offer: {
        type: Object
    },
    images: {
        type: Array
    },
    viewers: {
        type: Array
    },
    shiping_criteria: {
        type: Object
    }
    
},{timestamps: true})


module.exports = model('products', productSchema)