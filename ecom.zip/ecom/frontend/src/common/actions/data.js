export const products = [
    {
        id: 1,
        title: "Nokia 8.1 plus nosle edge",
        description: "Product description is here for product 1",
        category: "Mobile",
        price: 170,
        quantity: 4,
        item_details: {
            units: "GB",
            color: "Black",
            storage: 256, 
        },
        sold: false,
        offer: {
            discount: "2%",
            save_up_to: 1000,
            free:1,
            description: "This offer is validate till to April 31 2022"
        },
        images: ["https://m.media-amazon.com/images/I/91i99oeLm5L._UY879_.jpg", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://m.media-amazon.com/images/I/91i99oeLm5L._UY879_.jpg"],
        viewers: [{
            username: "user1@revvsales.com",
            rating: 5,
            like: true,
            comments: ["1st comments", "2nd comments"],
            images: []
        }],
        shiping_criteria: {
            on_date: Date(),
            shiping_charge: "Free"
        }
    },
    {
        id: 2,
        title: "Nokia 8.1 plus nosle edge",
        description: "Product description is here for product 2",
        category: "Men",
        price: 234,
        quantity: 4,
        item_details: {
            units: "XL",
            color: "Blue",
            storage: 0,
        },
        sold: false,
        offer: {
            discount: "2%",
            save_up_to: 1000,
            free:1,
            description: "This offer is validate till to April 31 2022"
        },
        images: ["https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://m.media-amazon.com/images/I/91i99oeLm5L._UY879_.jpg", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://m.media-amazon.com/images/I/91i99oeLm5L._UY879_.jpg"],
        viewers: [{
            username: "user1@revvsales.com",
            rating: 3,
            like: true,
            comments: ["1st comments", "2nd comments"],
            tag_images: []
        }],
        shiping_criteria: {
            on_date: Date.now(),
            shiping_charge: "Free"
        }
    },
    {
        id: 3,
        title: "Men large size pajama",
        description: "Product description is here for product 2",
        category: "Kids",
        price: 234,
        quantity: 4,
        item_details: {
            units: "XL",
            color: "Blue",
            storage: 0,
        },
        sold: false,
        offer: {
            discount: "2%",
            save_up_to: 1000,
            free:1,
            description: "This offer is validate till to April 31 2022"
        },
        images: ["https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png"],
        viewers: [{
            username: "user1@revvsales.com",
            rating: 3,
            like: true,
            comments: ["1st comments", "2nd comments"],
            tag_images: []
        }],
        shiping_criteria: {
            on_date: Date.now(),
            shiping_charge: "40"
        }
    },
        {
        id: 4,
        title: "Men large size pajama",
        description: "Product description is here for product 2",
        category: "Kids",
        price: 234,
        quantity: 4,
        item_details: {
            units: "XL",
            color: "Blue",
            storage: 0,
        },
        sold: false,
        offer: {
            discount: "2%",
            save_up_to: 1000,
            free:1,
            description: "This offer is validate till to April 31 2022"
        },
        images: ["https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png"],
        viewers: [{
            username: "user1@revvsales.com",
            rating: 3,
            like: true,
            comments: ["1st comments", "2nd comments"],
            tag_images: []
        }],
        shiping_criteria: {
            on_date: Date.now(),
            shiping_charge: "Free"
        }
    },
    {
        id: 5,
        title: "Men large size pajama",
        description: "Product description is here for product 2",
        category: "Kids",
        price: 234,
        quantity: 4,
        item_details: {
            units: "XL",
            color: "Blue",
            storage: 0,
        },
        sold: false,
        offer: {
            discount: "2%",
            save_up_to: 1000,
            free:1,
            description: "This offer is validate till to April 31 2022"
        },
        images: ["https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png", "https://res.cloudinary.com/dwpufqcyc/image/upload/v1642434762/imgstore/dmouneyxlhvmvbxflycu.png"],
        viewers: [{
            username: "user1@revvsales.com",
            rating: 3,
            like: true,
            comments: ["1st comments", "2nd comments"],
            tag_images: []
        }],
        shiping_criteria: {
            on_date: Date.now(),
            shiping_charge: "Free"
        }
    },
]