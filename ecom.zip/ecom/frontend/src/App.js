import './App.css';
import About from './components/about/About';
import Contact from './components/contact/Contact';
import Home from './pages/home/Home';
import SignUp from './components/authentication/SignUp';
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  Outlet,
  history
} from "react-router-dom";
import Navbar from './components/navbar/Navbar';
import Products from './components/product/Products';
import ProductDetails from './components/product/productdetails/ProductDetails';
import Cart from './components/cart/Cart';
import AddAddress from './components/address/AddAddress';
import  UserAuthentication  from './utlis/userAuthentication';
import SignIn from './components/authentication/SignIn';

function App() {
  return (
    <BrowserRouter>
      <Navbar/>
      <Routes>
          {/* Public routes */}
          <Route path="/" element={<Home/>}/>
          <Route path="/about" element={<About />}/>
          <Route path="/contact" element={<Contact />} />
        <Route path="/register" element={<SignUp />} />
        <Route path="/login" element={<SignIn/>}/>
          <Route path="/products" element={<Products />} />
          <Route path="/products/:paramsid" element={<ProductDetails />} />

        {/* Private routes */}
        <Route element={<UserAuthentication/>}>
          <Route path="/cart" element={<Cart />} />
          <Route path="/address" element={<AddAddress />} />
        </Route>
        </Routes>
      </BrowserRouter>
  );
}

export default App;

