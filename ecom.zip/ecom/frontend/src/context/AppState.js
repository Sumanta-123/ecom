import React, { useReducer, createContext, useEffect, useState } from 'react';
import { products } from '../common/actions/data';
// import {AppContext} from './appContext';
import productReducer from '../reducers/productReducer/productReducer';
import addressReducer from '../reducers/addressReducer/addressrReducer';
import cartReducer from '../reducers/cartReducer/cartReducer';
import authReducer from '../reducers/authReducer/authReducer';
import errorReducer from '../reducers/errorReducer/errorReducer';
import  api  from '../common/api/api';
export const Context = createContext({});
const state = {
  loader: false,
  address: [],
  product:[],
  cart: [],
  error:'',
  user:{isAuth:false, role:["admin", "retailer", "user"]}
}
export default function AppStateProvider({ children }) {
  // console.log(initialCartState)
  const [loader,setLoader] = useState(state.loader)
  const [product, dispatchProduct] = useReducer(productReducer, state)
  const [address, dispatchAddress] = useReducer(addressReducer, state);
  const [cart, dispatchCart] = useReducer(cartReducer, state);
  const [user, dispatchAuth] = useReducer(authReducer, state);
  const [error, dispatchError] = useReducer(errorReducer, state)

  //Axis fetching all product from backend
  useEffect(() => {
    const sendGetRequest = async () => {
        try {
            const resp = await api.get("/products");      
            dispatchProduct({ type:"GET_ALL_PRODUCTS", payload: resp.data.products })
        } catch (err) {
            // Handle Error Here
            console.error(err);
        }
    };
    sendGetRequest();
  },[])
  //Get all product and set in local state variable
  return (
    <Context.Provider
      value={{
        addressState: address.address,
        dispatchCart,
        cartState: cart.cart,
        dispatchAddress,
        prodState: product.product,
        dispatchProduct,
        userState: user.user,
        dispatchAuth,
        errorState: error.error,
        dispatchError
      }}
    >
      {children}
    </Context.Provider>
  )
}
