import { PRODUCT_DETAILS , GET_ALL_PRODUCTS} from "../../actions/action";
const errorReducer = (state, action) => {
    switch (action.type)
    {
        case "IS_ERROR": {
            return {
                error: action.payload
            }
        };
        case "NO_ERROR": {
            return { error: '' }
        };
        default:
            return {
                error:''
            }
    }
}
export default errorReducer;
