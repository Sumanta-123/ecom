import { PRODUCT_DETAILS , GET_ALL_PRODUCTS} from "../../actions/action";
const productReducer = (state, action) => {
    console.log(action.payload)
    switch (action.type)
    {
        case GET_ALL_PRODUCTS:
            return {
                ...state.product,
                product: action.payload
            }
        case PRODUCT_DETAILS:
            return {
                product: state.product.find(prod => {
                    if (prod.id === action.payload)
                    {
                        return prod
                    }
                })
            }
        default:
            return state;
    }
}
export default productReducer;
