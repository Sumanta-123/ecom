import { REGISTER_USER, LOGIN_USER, LOGOUT_USER } from "../../actions/action";

import React from 'react'

const authReducer = (state, action) => {
    switch (action.type)
    {
        case REGISTER_USER:
            return {
                ...state.user,
                user: action.payload 
            }
        case LOGIN_USER:
            return {
                ...state.user,
            }
        case LOGOUT_USER:
            return {
                ...state.user,
            }
        default:
            return {
                state
            }
    }
}
export default authReducer;