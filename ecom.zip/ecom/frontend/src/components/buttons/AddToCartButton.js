import React, { useState } from 'react';
import './Button.css'

const AddToCartButton = (props) => {
  return(
    <button
      className="cartButton"
      onClick={props.addToCart()}
      >
      {props.button.title}
    </button>
  )
}
export default AddToCartButton;
