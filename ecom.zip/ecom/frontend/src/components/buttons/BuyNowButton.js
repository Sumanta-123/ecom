import React from 'react'

export default function BuyNowButton(props) {
  return (
    <button className="cartButton">{props.title}</button>
  )
}
