import React, {useContext, useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { Context } from "../../context/AppState";

export default function AddressList(props) {
    const { addressState } = useContext(Context)
    const [check, setCheck] = useState(true)
    const addressList = addressState.map((address, i) => {
        return (
            <div className="selectedAdress" key={i}>
                <div>
                    <input
                        type="radio"
                        id={`address-${address.address_id}`}
                        name="address"
                        checked={address.select_id===check}
                        onChange={(e)=>props.setDeliveryAddress(e, address.address_id)}
                    />
                    <label htmlFor="address">Choose</label>
                    <button name="address-update"
                        onClick={(e)=>props.updateAddress(e, address.address_id)}
                    >
                        <span>&#9998;</span>
                    </button>
                    <label htmlFor="address-update">Update</label>
                </div>
                <div>
                    <span>Recipient name: <strong>{address.recipient_name}</strong></span>
                    <span>Recipient mobile: <strong>{address.recipient_mobile }</strong></span>
                    <span>Address: <strong>{`${address.address_one}, ${address.address_two}, ${address.city}, ${address.state}-${address.zip}`}</strong></span>
                </div>
            </div>
        )})
    return (
      <div className="addressContainer">
        <h2>Select your address</h2>
        <div className="address">
            <form className="adddressForm">
            {addressList}
            </form>
        </div>
    </div>
  )
}
