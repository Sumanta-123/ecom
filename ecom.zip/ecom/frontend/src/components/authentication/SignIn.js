import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Auth.css';
export default function SignIn() {
    const [login, setLogin] = useState({ username: "", password: "" })
    const handleChange = (event) => {
        event.preventDefault();
        const [name, value] = event.target;
        console.log(name, value)
    }
    const handleSubmit = () => {
    
}
  return (
            <div className="authForm">
            <h2>BKD Spices</h2>
            <form onSubmit={handleSubmit} className="authContainer">
                <h2>Login your account</h2>
                <label>Username</label>
                <input type="text" value={login.username} name="username" className="userInfo" onChange={handleChange} />
                <label>Password</label>
                <input type="text" value={login.password} name="password" className="userInfo" onChange={handleChange}  placeholder="At least 6 characters"/>
                <button className="submitButton">Login</button>
                <div className="lineDevider">
                    <span>By creating an account or logging in, you agree to Amazon’s Conditions of Use and Privacy Policy.</span>
                </div>
                <div className="formFooter">
                    <div>
                        If you don't have an account? <Link to="/register">Sign up </Link>
                    </div>
                    <div>
                        Buying for work? <Link to="/register">Create a free business account</Link>
                    </div>
                </div>
            </form>
        </div>
  )
}
