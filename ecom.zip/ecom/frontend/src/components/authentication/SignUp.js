import './Auth.scss';
import React, { useState, useContext, useEffect, useRef} from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Context } from '../../context/AppState';
import { REGISTER_USER } from '../../actions/action';
import api from '../../common/api/api';
import MessagePopups from '../../components/popups/MessagePopups';
const initialState = {
    user: {
        name: '',
        mobile: '',
        email: '',
        password: '',
        confirm_password: '',
        isAuthenticate: true
    }
}

function SignUp() {
    //User state
    const { userState, dispatchAuth, dispatchError } = useContext(Context);
    //Error message
    // const [errMsg, setErrMsg] = useState('');
    const inputrRef = useRef();
    const errRef = useRef();
    //Navigate 
    const naviGate = useNavigate()
   //Store user in local storage
    const authUser = JSON.stringify(userState)
    localStorage.setItem("user", authUser);
    
    const [user, setUser] = useState(initialState.user);
    const { name, mobile, email, password, confirm_password } = user;

    const handleChange = (e) => {
        e.preventDefault();
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value
        });
        e.target.focus();
        dispatchError({type:'NO_ERROR', payload:''})
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        //before dispatch validate form
        const registerUser = async () => {
            try {
               const res = await api.post("/users/register-user", {
                    name: name,
                    phone: mobile,
                    email: email,
                    password: password
               })
                console.log(res)
                // naviGate("/product", {replace:false})
            } catch (err) {
                if (err)
                {
                    dispatchError({type:'IS_ERROR', payload:err.response.data.msg})
                }
            }
        }
        registerUser();
    }
    return (
        <div className="authForm">
            <MessagePopups/>
            <h2>BKD Spices</h2>
            <form onSubmit={handleSubmit} className="authContainer">
                <h2>Create Account</h2>
                <label htmlFor="name">Your name</label>
                <input
                    type="text"
                    ref={inputrRef}
                    value={name}
                    name="name"
                    className="userInfo"
                    onChange={handleChange}
                />
                <label htmlFor="mobile">Mobile number</label>
                <input
                    type="text"
                    ref={inputrRef}
                    value={mobile}
                    name="mobile"
                    className="userInfo"
                    onChange={handleChange}
                />
                <label htmlFor="email">Email</label>
                <input
                    type="text"
                    ref={inputrRef}
                    value={email}
                    name="email"
                    className="userInfo"
                    onChange={handleChange}
                />
                <label htmlFor="password">Password</label>
                <input
                    type="text"
                    ref={inputrRef}
                    value={password}
                    name="password"
                    className="userInfo"
                    onChange={handleChange}
                    placeholder="At least 6 characters"
                />
                <label>Confirm password</label>
                <input
                    type="text"
                    ref={inputrRef}
                    value={confirm_password}
                    name="confirm_password"
                    onChange={handleChange}
                    className="userInfo"
                />
                <button className="submitButton">Continue</button>
                <div className="lineDevider">
                    <span>By creating an account or logging in, you agree to Amazon’s Conditions of Use and Privacy Policy.</span>
                </div>
                <div className="formFooter">
                    <div>
                        Already have an account? <Link to="/signin">Sign in </Link>
                    </div>
                    <div>
                        Buying for work? <Link to="/register">Create a free business account</Link>
                    </div>
                </div>
            </form>
        </div>
    );
}

export default SignUp;
