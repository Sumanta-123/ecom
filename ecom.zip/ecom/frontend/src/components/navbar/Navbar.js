import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import Button from '../buttons/Button';
import SearchItems from '../search-items/SearchItems';
import { Context } from '../../context/AppState'
import "./Navbar.css";
function Navbar() {
    const { cartState } = useContext(Context)
    // console.log(cartState)
    return (
        <div className="navBar">
            <div>
                <Link to="/"><Button title={'BKD Spices'}/></Link>
                 <Button title={"Today's Offers"}/>
            </div>
            <div>
                <SearchItems/>
            </div>
            <div>
                <Button title={"Sign In \n Accounts"} />
                <Link to="/cart" className="navCartBox">
                    <span>Cart:</span>
                    {/* <span>{cartState.length}</span> */}
                </Link>
            </div>
        </div>
        
    );
}

export default Navbar;
