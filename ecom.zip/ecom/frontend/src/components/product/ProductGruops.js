import React from 'react';
import './Product.css';
import { products } from "../../common/actions/data";
import { Link } from "react-router-dom";
export default function ProductGrupos(props) {
  // console.log(products)
  const prod = products.filter(prods => {if(prods.category==="Kids") return prods})
  console.log(prod)
  const groupProd =  prod.map((group, key) => {
      return(
        <Link to="/products" className="groupItems" key={key}>
          <div className="grDetails">
            <img src={group.images[0]} width="100" height="100" />
            <h5>{group.category}</h5>
          </div>
        </Link>
      )
    })
  return (
    <div className="cards">
      <div className="cardHeader"></div>
      <h2>Product heading</h2>
      <div className="cardBody">
        {groupProd}
      </div>
      <div className="cardFooter">
        <Link to="/">
          See more
        </Link>
      </div>
    </div>
  )
}
