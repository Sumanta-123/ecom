import React from 'react';

const TopSelectionProducts =()=> {
    return (
        <div className="productContainer bgSecondary">
            <h3>Top Selections</h3>
            <h3>Top Selections</h3>
            <h3>Top Selections</h3>
            <h3>Top Selections</h3>
        </div>
    );
}

export default TopSelectionProducts;
