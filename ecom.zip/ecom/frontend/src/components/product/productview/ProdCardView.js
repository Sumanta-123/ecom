import React, { useContext, useState } from 'react';
import "./prodview.css";
import { Link, useNavigate, Navigate, useLocation } from 'react-router-dom';
import { Context } from '../../../context/AppState';
export default function ProdCardView(props) {
  console.log(props.product.images[0])
  const { location } = useLocation();
  const [add, setAddToCart] = useState(false);
  const naviGate = useNavigate();
  const { dispatchCart, userState, prodState } = useContext(Context);
  //Add to cart 
  const handleAddToCart = (e, id) => {
    e.preventDefault()
    e.stopPropagation();
    !userState.isAuth
    ?
      naviGate("/register", { replace: false})
    :
      setAddToCart(true)
      const [sigleProduct] = prodState.filter((eachProd) => {
        if (eachProd._id === id) return eachProd
      })
      const cartObjet = {
        product: sigleProduct,
        isAddToCart: true,
        isComplete: false,
        isPurchase: false,
        prodQuantity: 1
      }
      dispatchCart({ type: "ADD_TO_CART", payload: cartObjet })
  }

  return (
    <Link to={`/products/${props.product._id}`} className="pCardContainer">
          <div className="pCards">
            <div className="pCardHeader">
              <div className="pCardImgBox">
                <img className="cardImg" src={props.product.images[0]}/>
              </div>
            </div>
            <div className="pCardBody">
              <h5>
                {props.product.description}
              </h5>
            </div>
            <div className="pCardFooter">
              <div><span>⭐⭐⭐⭐⭐</span><span>200</span></div>
              <div><span>Rs:</span><span>{props.product.price}</span><span>{props.product.price}
          </span>
            {/* <span>({props.product.offer}% off)</span> */}
          </div>
              <div><span>Get it</span> <strong>On Date</strong></div>
              {/* <div>Delivery charge is {props.product.shiping_criteria.shiping_charge}</div> */}
              <button disabled={add ? true : false} onClick={(e) => handleAddToCart(e,props.product._id)}>Add to cart</button>
            </div>
          </div>
    </Link>
  )
}
