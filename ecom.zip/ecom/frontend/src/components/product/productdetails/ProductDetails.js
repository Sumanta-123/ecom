import React, { useContext, useEffect, useState } from 'react';
import { Link , useNavigate, useParams} from 'react-router-dom';
import { Context } from '../../../context/AppState';
import Loading from '../../loader/Loading';
import "./productdetails.css";

export default function ProductDetails() {
    const { paramsid } = useParams();
    const naviGate = useNavigate()
    const [image, setImage] = useState();
    const { cartState, dispatchCart, userState, prodState } = useContext(Context);

    const productDetails = prodState.find((prod) => {
        if (prod._id === paramsid)
        {
            return prod;
        }
    })

    const isInCart = cartState.find(
        ({ product }) => product._id == paramsid
    );

    //Thumbnail image changes
    const handleChangeImage = (img) => {
        setImage(img)
    }
    
    //Add to cart
    const handleAddToCart = (e) => {
        !userState.isAuth
            ?
            naviGate("/register", { replace: false })
            :
                e.preventDefault()
                const cartObjet = {
                    product: productDetails,
                    isAddToCart: true,
                    isComplete: false,
                    isPurchase: false,
                    prodQuantity: 1
                }
                dispatchCart({ type: "ADD_TO_CART", payload: cartObjet })
                naviGate(`/cart`, { replace: true })
    }
    
    const goToCart = () => {
        userState.isAuth ?
            naviGate("/register", { replace: false })
            :
            naviGate(`/cart`, { replace: false })
        }
    if (!productDetails)
    {
        return(<Loading/>)
    }
  return (
    <div className="pDetailContainer">
          <div className="pDetailImgPanel">
              <div className="pDetailIconImg">
                  {productDetails.images.map((image, _index)=>{
                      return (
                          <img
                              key={_index}
                              src={image} width="40" height="40"
                              onClick={() => handleChangeImage(image)}
                          />)
                    })}
              </div>
              <div className="pDetailLargeImg">
                  <img src={productDetails.images[0]} width="600" height="600"/>
              </div>
          </div>
          <div className="pDetailPanel">
              <div className="pDetailDesp">
                  <h3>
                      {productDetails.description}
                  </h3>
              </div>
              <div className="pPriceBox">
                  <table className="pMrpTable">
                      <tbody>
                          <tr>
                              <td>⭐⭐⭐⭐⭐</td>
                              <td><span>9</span> ratings</td>
                          </tr>
                          <tr>
                              <td>M.R.P.:</td>
                              <td><span>₹:</span>200.00</td>
                          </tr>
                            <tr>
                              <td>Discount:</td>
                              <td><span>₹:</span>200.00</td>
                          </tr>
                          <tr>
                              <td></td>
                              <td>Offer ends <span>1</span> day</td>
                          </tr>
                            <tr>
                              <td></td>
                              <td><span>Includes all taxes</span></td>
                          </tr>
                      </tbody>
                    </table>
                  <div className="pPricePerItem">
                        <div>
                            <div className="pTotalPrice">
                              <span>Total</span> <span>₹:</span> <strong>{productDetails.price}</strong>
                            </div>
                        </div>
                        <div>
                          <div>
                              <span>Free Delivery:</span> <strong>Thursday, May 19</strong>
                          </div>
                          <div>
                              {
                                isInCart===undefined || cartState.length === 0 ?
                                    <button
                                        className="addToCartBtn"
                                        onClick={(e) => handleAddToCart(e)} >
                                        Add to cart
                                    </button>
                                  : <button
                                        className="addToCartBtn"
                                        onClick={goToCart} >
                                        Go to cart
                                    </button>
                                }
                              <button to="/">Buy now</button>
                          </div>
                        </div>
                  </div>
              </div>
              <div className="pFeatureDetails">
                  <ul>
                      <li>Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                      <li>Capacity 6.5 Kg: Suitable for families with 3 to 4 members</li>
                  </ul>
              </div>
          </div>
    </div>
  )
}
