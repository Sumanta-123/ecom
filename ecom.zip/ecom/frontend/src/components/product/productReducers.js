import { useReducer, useState } from "react";

import React from 'react';

function reducers(state, action) {
    switch (action.type) {
        case value:
            
            break;
    
        default:
            break;
    }
}
