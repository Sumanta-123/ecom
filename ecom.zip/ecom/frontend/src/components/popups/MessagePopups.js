import React, { useContext } from 'react'
import './MessagePopup.css';
import { Context } from '../../context/AppState';
export default function MessagePopups() {
    const { errorState,dispatchError } = useContext(Context);
    const handleCloseMessage = () => {
        dispatchError({typeof:'NO_ERROR', payload:''})
    }
  return (
      <div className={errorState?'message':'offscreen'}>
          <span>{errorState}</span>
          <span onClick={handleCloseMessage}>x</span>
    </div>
  )
}
