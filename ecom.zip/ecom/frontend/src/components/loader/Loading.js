import React from 'react'
import './loader.css';
export default function Loading() {
  return (
    <div className="LoadingContainer">
          <div className="loader">Loading...</div>
    </div>
  )
}
