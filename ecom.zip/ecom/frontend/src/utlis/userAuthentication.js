import { useContext } from "react";
import { useLocation, Navigate, Outlet } from "react-router-dom";
import { Context } from "../context/AppState";
const user = JSON.parse(localStorage.getItem("user"));
const UserAuthentication = () => {
    // const [isAuth, setAuthentication] = useState(false)
    const  {userState}  = useContext(Context);
    // console.log(userState)
    const { location } = useLocation();
    return (
        userState.isAuth ? <Outlet /> : <Navigate to="/register" state={{from: location}} replace/>
    )
}

export default UserAuthentication;